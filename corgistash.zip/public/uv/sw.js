importScripts('/uv/uv.bundle.js');
importScripts('/uv/uv.config.js');

// Explicitly set the config to match our server
self.__uv$config.bare = '/bare/';
self.__uv$config.prefix = '/uv/service/';

importScripts('/uv/uv.sw.js');

const sw = new UVServiceWorker();

self.addEventListener('fetch', (event) => {
    event.respondWith(sw.fetch(event));
});
