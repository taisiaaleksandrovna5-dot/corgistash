import React, { useState, useEffect, useRef } from "react";
import { Search, Home, Gamepad2, Settings, Dog, ArrowLeft, ArrowRight, RotateCw, X, Maximize2, Play, Pause, SkipForward, Music, Heart, ArrowDownAZ, Plus, ExternalLink } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const GAMES = [
  { id: "rooftop-snipers", name: "Rooftop Snipers", path: "/games/rooftop-snipers.html", image: "https://images.crazygames.com/rooftop-snipers/20201026115908/rooftop-snipers-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "A chaotic two-player sniper game. Push your opponent off the roof to win!" },
  { id: "stumble-guys", name: "Stumble Guys", path: "/games/stumble-guys.html", image: "https://images.crazygames.com/stumble-guys/20221115115908/stumble-guys-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "A chaotic multiplayer knockout race game. Be the last one standing!" },
  { id: "gd3d", name: "Geometry Dash 3D", path: "/games/gd3d.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/322170/capsule_616x353.jpg", category: "Skill", description: "Experience the rhythm-based platformer in a full 3D environment." },
  { id: "gd-lite", name: "Geometry Dash Lite", path: "/games/gd-lite.html", image: "https://e3334afd.cf-nate.pages.dev/0/g/geodash/game/splash.png", category: "Skill", description: "The official lite version of the iconic rhythm platformer." },
  { id: "grow-your-garden", name: "Grow Your Garden", path: "/games/grow-your-garden.html", image: "https://cdn.jsdelivr.net/gh/bubbls/UGS-Assets@main/grow-your-garden/loading.png", category: "Casual", description: "Quietly grow your garden in this relaxing plant-nurturing game." },
  { id: "drive-mad", name: "Drive Mad", path: "/games/drive-mad.html", image: "https://images.crazygames.com/drive-mad/20221101103233/drive-mad-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "Drive your truck through challenging physics-based obstacle courses." },
  { id: "drift-boss", name: "Drift Boss", path: "/games/drift-boss.html", image: "https://images.crazygames.com/drift-boss/20201026115908/drift-boss-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "Master the art of timing and drifting in this high-speed car game." },
  { id: "happy-wheels", name: "Happy Wheels", path: "/games/happy-wheels.html", image: "https://images.crazygames.com/happy-wheels/20201202115908/happy-wheels-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Skill", description: "Navigate dangerous obstacle courses with various colorful characters." },
  { id: "red-ball", name: "Red Ball", path: "/games/red-ball.html", image: "https://images.crazygames.com/red-ball/20201026115908/red-ball-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Platformer", description: "Roll and jump your way through physics-based puzzles." },
  { id: "red-ball-2", name: "Red Ball 2", path: "/games/red-ball-2.html", image: "https://images.crazygames.com/red-ball-2/20201026115908/red-ball-2-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Platformer", description: "The sequel to Red Ball with even more challenging puzzle levels." },
  { id: "10-bullets", name: "10 Bullets", path: "/games/10-bullets.html", image: "https://images.crazygames.com/10-bullets/20201026115908/10-bullets-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Shooter", description: "Destroy as many ships as possible with only 10 bullets." },
  { id: "friday", name: "Pico's Game", path: "/games/friday.html", image: "https://www.lexaloffle.com/bbs/carthumbs/friday-0.png", category: "Action", description: "A fast-paced action game featuring the legendary character Pico." },
  { id: "pvz", name: "Plants vs Zombies", path: "/games/pvz.html", image: "https://images.crazygames.com/plants-vs-zombies/20201026115908/plants-vs-zombies-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Strategy", description: "Defend your lawn from zombies using a variety of powerful plants." },
  { id: "10-minutes-till-dawn", name: "10 Minutes Till Dawn", path: "/games/10-minutes-till-dawn.html", image: "https://cdn.jsdelivr.net/gh/bubbls/UGS-Assets@main/10minutestilldawn/logo.png", category: "Shooter", description: "Survive for ten minutes against a horde of eldritch monsters." },
  { id: "slope-plus", name: "Slope Plus", path: "/games/slope-plus.html", image: "https://images.crazygames.com/slope/20201026115908/slope-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Skill", description: "Roll down a futuristic 3D city at high speeds while avoiding obstacles." },
  { id: "slope-2-player", name: "Slope 2 Player", path: "/games/slope-2-player.html", image: "https://images.crazygames.com/slope-2-player/20201026115908/slope-2-player-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Skill", description: "Race against a friend in this two-player version of the hit game Slope." },
  { id: "smash-karts", name: "Smash Karts", path: "/games/smash-karts.html", image: "https://images.crazygames.com/smash-karts/20201026115908/smash-karts-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "Fast-paced multiplayer kart battle arena with weapons." },
  { id: "snail-bob", name: "Snail Bob", path: "/games/snail-bob.html", image: "https://images.crazygames.com/snail-bob/20201026115908/snail-bob-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Puzzle", description: "Solve physics puzzles to help Snail Bob reach the exit safely." },
  { id: "fnaf1", name: "FNAF 1", path: "/games/fnaf1.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/319510/capsule_616x353.jpg", category: "Horror", description: "Can you survive five nights as a security guard at Freddy Fazbear's Pizzeria?" },
  { id: "fnaf2", name: "FNAF 2", path: "/games/fnaf2.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/332800/capsule_616x353.jpg", category: "Horror", description: "The sequel to FNAF with new characters and more jumpscares." },
  { id: "fnaf3", name: "FNAF 3", path: "/games/fnaf3.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/354140/capsule_616x353.jpg", category: "Horror", description: "Thirty years after Freddy's closed, a new horror attraction awakens." },
  { id: "fnaf4", name: "FNAF 4", path: "/games/fnaf4.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/388090/capsule_616x353.jpg", category: "Horror", description: "This time, the horror follows you home in the most terrifying installment yet." },
  { id: "fnaf-sl", name: "FNAF Sister Location", path: "/games/fnaf-sl.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/506610/capsule_616x353.jpg", category: "Horror", description: "A deep dive into the disturbing secrets of the Fazbear franchise." },
  { id: "fnaf-6", name: "FNAF 6", path: "/games/fnaf-6.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/738060/capsule_616x353.jpg", category: "Horror", description: "Manage your very own Pizzeria while fending off scrap animatronics." },
  { id: "fnaf-ucn", name: "Ultimate Custom Night", path: "/games/fnaf-ucn.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/871720/capsule_616x353.jpg", category: "Horror", description: "Customize your own horror experience with over 50 characters." },
  { id: "rocking-life-2d", name: "Rocking Life 2D", path: "/games/rocking-life-2d.html", image: "https://images.crazygames.com/rocking-life-2d/20201026115908/rocking-life-2d-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "Live the life of a rockstar in this fun and quirky 2D simulator." },
  { id: "sniper-shot", name: "Sniper Shot", path: "/games/sniper-shot.html", image: "https://images.crazygames.com/sniper-shot/20201026115908/sniper-shot-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Shooter", description: "Test your aim in this slow-motion sniper simulation game." },
  { id: "snow-rider-3d", name: "Snow Rider 3D", path: "/games/snow-rider-3d.html", image: "https://images.crazygames.com/snow-rider-3d/20201026115908/snow-rider-3d-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "Race down snowy mountains on a sleigh while dodging hazards." },
  { id: "soccer-bros", name: "Soccer Bros", path: "/games/soccer-bros.html", image: "https://images.crazygames.com/soccer-bros/20201026115908/soccer-bros-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Sports", description: "Addictive and fast-paced soccer game with fun physics-based characters." },
  { id: "snow-road", name: "Snow Road", path: "/games/snow-road.html", image: "https://images.crazygames.com/snow-road/20201026115908/snow-road-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "Similar to Slope, but on a snowy road with pine trees and cliffs." },
  { id: "soccer-random", name: "Soccer Random", path: "/games/soccer-random.html", image: "https://images.crazygames.com/soccer-random/20201026115908/soccer-random-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Sports", description: "A hilarious soccer game where every round is completely random." },
  { id: "sonic-exe", name: "Sonic.exe", path: "/games/sonic-exe.html", image: "https://images.crazygames.com/sonic-exe/20201026115908/sonic-exe-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Horror", description: "The classic internet creepypasta brought to life in game form." },
  { id: "retro-bowl", name: "Retro Bowl", path: "/games/retro-bowl.html", image: "https://images.crazygames.com/retro-bowl/20201026115908/retro-bowl-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Sports", description: "Pixel-perfect American football management game with deep strategy." },
  { id: "bike-of-hell", name: "steal a brainrot", path: "/games/bike-of-hell.html", image: "https://images.crazygames.com/bike-of-hell/20231123115908/bike-of-hell-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "A chaotic bike racing game with brainrot-themed obstacles." },
  { id: "sprunked", name: "Sprunked", path: "/games/sprunked.html", image: "https://cdn.jsdelivr.net/gh/bubbls/UGS-Assets@main/sprunked/cover.png", category: "Music", description: "Create your own funky tracks in this interactive music simulation." },
  { id: "sprunki", name: "Sprunki", path: "/games/sprunki.html", image: "https://images.crazygames.com/sprunki/20241026115908/sprunki-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Music", description: "Compose melodies and rhythms with quirky characters." },
  { id: "steal-brainrot", name: "Steal Brainrot Online", path: "/games/steal-brainrot-online.html", image: "https://images.crazygames.com/steal-brainrot-online/20241026115908/steal-brainrot-online-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "The ultimate brainrot experience, now unblocked and online." },
  { id: "stealth-assassin", name: "Stealth Assassin", path: "/games/stealth-assassin.html", image: "https://images.crazygames.com/stealth-assassin/20201026115908/stealth-assassin-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "Eliminate targets without being seen in this tactical stealth game." },
  { id: "stealth-master", name: "Stealth Master", path: "/games/stealth-master.html", image: "https://images.crazygames.com/stealth-master/20201026115908/stealth-master-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "Infiltrate enemy bases and take down guards as a master assassin." },
  { id: "this-is-the-only-level", name: "This Is The Only Level", path: "/games/this-is-the-only-level.html", image: "https://images.crazygames.com/this-is-the-only-level/20201026115908/this-is-the-only-level-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Platformer", description: "Prove your platforming skills in the only level you'll ever need." },
  { id: "baldis-basics", name: "Baldi's Basics", path: "/games/baldis-basics.html", image: "https://upload.wikimedia.org/wikipedia/en/6/6f/Baldi%27s_Basics_in_Education_and_Learning_cover.png", category: "Horror", description: "Don't let Baldi catch you while you collect notebooks in this uncanny educational horror game." },
  { id: "deltarune", name: "Deltarune", path: "/games/deltarune.html", image: "https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/1671210/capsule_616x353.jpg", category: "Action", description: "The mysterious and exciting successor to Undertale." },
  { id: "paper-io-2", name: "Paper.io 2", path: "/games/paper-io-2.html", image: "https://images.crazygames.com/paperio2/20201026115908/paperio2-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Action", description: "Capture territory and outsmart other players in this competitive IO game." },
  { id: "escape-road", name: "Escape Road", path: "/games/escape-road.html", image: "https://images.crazygames.com/escape-road/20241014092716/escape-road-cover?auto=format%2Ccompress&q=45&cs=strip&ch=DPR&w=1200&h=630&fit=crop", category: "Driving", description: "Outrun the law and escape the chase in this high-octane driving game." },
  { id: "my-teardrop", name: "myTeardrop", path: "/games/my-teardrop.html", image: "https://cdn.jsdelivr.net/gh/whatthezip/myTeardrop@main/play/Sprites/Load.png", category: "Casual", description: "Adopt and take care of your very own Teardrop character." },
];

const QUICK_SITES = [
  { name: "DuckDuckGo", url: "https://duckduckgo.com" },
  { name: "YouTube", url: "https://youtube.com" },
  { name: "Discord", url: "https://discord.com" },
  { name: "TikTok", url: "https://tiktok.com" },
  { name: "Roblox", url: "https://roblox.com" },
  { name: "Google", url: "https://google.com" }
];

export default function App() {
  const [authStatus, setAuthStatus] = useState<"loading" | "unauthenticated" | "authenticated" | "guest">("loading");
  const [currentUser, setCurrentUser] = useState<{username: string} | null>(null);
  const [proxyUrl, setProxyUrl] = useState<string | null>(null);
  // Tabs and Filter State
  const [activeTab, setActiveTab] = useState<"home" | "games" | "proxy" | "settings">("home");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [playedHistory, setPlayedHistory] = useState<string[]>(() => {
    const saved = localStorage.getItem("corgi-played-history");
    return saved ? JSON.parse(saved) : [];
  });
  const [showThumbnailNote, setShowThumbnailNote] = useState(true);
  const [isTheaterMode, setIsTheaterMode] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const loadingMessages = [
    "Waking up the local corgis...",
    "Digging for high-score bones...",
    "Unwrapping the bytes...",
    "Borking at the server...",
    "Doing a big sploot...",
    "Scanning for squirrel-free packets...",
    "Chasing the loading tail...",
    "Preparing the treasure trove...",
  ];
  const [currentLoadingMsg, setCurrentLoadingMsg] = useState(loadingMessages[0]);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(() => {
    return localStorage.getItem("corgi-reviewed") === "true";
  });
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  // Check auth on mount
  useEffect(() => {
    const savedSession = localStorage.getItem("corgi-session");
    if (savedSession) {
      if (savedSession === "guest") {
        setAuthStatus("guest");
      } else {
        setCurrentUser(JSON.parse(savedSession));
        setAuthStatus("authenticated");
      }
    } else {
      setAuthStatus("unauthenticated");
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("corgi-session");
    setCurrentUser(null);
    setAuthStatus("unauthenticated");
    setProxyUrl(null);
    setActiveTab("home");
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [browserSearchQuery, setBrowserSearchQuery] = useState("");
  const [currentTitle, setCurrentTitle] = useState("CorgiStash");
  const [isProxyReady, setIsProxyReady] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [tabs, setTabs] = useState<{id: string, url: string, title: string, isLoading: boolean}[]>([]);
  const [activeTabId, setActiveTabId] = useState<string | null>(null);
  const [gameSearchQuery, setGameSearchQuery] = useState("");
  const [homeSuggestions, setHomeSuggestions] = useState<(any)[]>([]);
  const [gameSuggestions, setGameSuggestions] = useState<typeof GAMES>([]);
  const [showHomeSuggestions, setShowHomeSuggestions] = useState(false);
  const [showGameSuggestions, setShowGameSuggestions] = useState(false);
  const [homeSuggestionIndex, setHomeSuggestionIndex] = useState(-1);
  const [gameSuggestionIndex, setGameSuggestionIndex] = useState(-1);
  const [sortOrder, setSortOrder] = useState<"default" | "az">("default");

  // Fallback for hanging loader
  useEffect(() => {
    if (isLoading) {
      const timer = setTimeout(() => {
        setIsLoading(false);
      }, 12000); // 12 second fail-safe
      return () => clearTimeout(timer);
    }
  }, [isLoading]);

  // Update Home Suggestions
  useEffect(() => {
    if (searchQuery.length > 1) {
      const filteredGames = GAMES.filter(g => g.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 5).map(g => ({ ...g, type: 'game' }));
      const filteredSites = QUICK_SITES.filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()) || s.url.toLowerCase().includes(searchQuery.toLowerCase())).map(s => ({ ...s, type: 'site' }));
      setHomeSuggestions([...filteredGames, ...filteredSites].slice(0, 8));
    } else {
      setHomeSuggestions([]);
    }
  }, [searchQuery]);

  // Registration logic
  useEffect(() => {
    async function initSW() {
      if ('serviceWorker' in navigator) {
        try {
          await navigator.serviceWorker.register('/uv/sw.js');
          setIsProxyReady(true);
        } catch (e) {
          console.error("SW registration failed", e);
        }
      }
    }
    initSW();
  }, []);


  // Update Game Suggestions
  useEffect(() => {
    if (gameSearchQuery.length > 1) {
      const filtered = GAMES.filter(g => g.name.toLowerCase().includes(gameSearchQuery.toLowerCase())).slice(0, 5);
      setGameSuggestions(filtered);
    } else {
      setGameSuggestions([]);
    }
  }, [gameSearchQuery]);
  const [userIp, setUserIp] = useState<string>("Detecting...");
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem("corgi-favorites");
    return saved ? JSON.parse(saved) : [];
  });
  const [history, setHistory] = useState<{url: string, time: number}[]>(() => {
    const saved = localStorage.getItem("corgi-history");
    return saved ? JSON.parse(saved) : [];
  });
  
  // Theme State
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem("corgi-theme");
    return saved || "golden";
  });

  const [customColor, setCustomColor] = useState(() => {
    return localStorage.getItem("corgi-custom-color") || "#FF9F00";
  });
  
  const [pattern, setPattern] = useState(() => {
    const saved = localStorage.getItem("corgi-pattern");
    return saved || "bones";
  });

  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Persistence
  useEffect(() => {
    localStorage.setItem("corgi-theme", theme);
    localStorage.setItem("corgi-custom-color", customColor);
    localStorage.setItem("corgi-pattern", pattern);
    localStorage.setItem("corgi-history", JSON.stringify(history.slice(0, 10)));
    localStorage.setItem("corgi-favorites", JSON.stringify(favorites));
    localStorage.setItem("corgi-played-history", JSON.stringify(playedHistory));
  }, [theme, customColor, pattern, history, favorites, playedHistory]);

  useEffect(() => {
    let interval: any;
    if (isLoading) {
      setLoadingProgress(0);
      setCurrentLoadingMsg(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      interval = setInterval(() => {
        setLoadingProgress(prev => {
          if (prev >= 95) return prev;
          const increment = Math.random() * 15;
          return Math.min(prev + increment, 95);
        });
        
        if (Math.random() > 0.7) {
          setCurrentLoadingMsg(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
        }
      }, 400);
    } else {
      setLoadingProgress(100);
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound("click");
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fid => fid !== id) : [...prev, id]
    );
  };

  const THEMES = {
    golden: { primary: "#FF9F00", bg: "#FEF9EF", border: "#EAD7C3", text: "#4A3B31", accent: "#FF4D4D", card: "#FFFFFF", input: "#FFFFFF", isDark: false },
    midnight: { primary: "#8B5CF6", bg: "#0F172A", border: "#334155", text: "#F8FAFC", accent: "#F43F5E", card: "#1E293B", input: "#0F172A", isDark: true },
    berry: { primary: "#EC4899", bg: "#FDF2F8", border: "#F9A8D4", text: "#701A75", accent: "#8B5CF6", card: "#FFFFFF", input: "#FFFFFF", isDark: false },
    forest: { primary: "#10B981", bg: "#F0FDF4", border: "#86EFAC", text: "#064E3B", accent: "#F59E0B", card: "#FFFFFF", input: "#FFFFFF", isDark: false },
  };

  const formatRelativeTime = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return "just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    return `${days}d ago`;
  };

  const playSound = (type: "hover" | "click" | "launch") => {
    const sounds = {
      hover: "https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3",
      click: "https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3",
      launch: "https://assets.mixkit.co/active_storage/sfx/1110/1110-preview.mp3" // Woof sound
    };
    const audio = new Audio(sounds[type]);
    audio.volume = 0.2;
    audio.play().catch(() => {}); // Catch browser auto-play blocks
  };

  const currentTheme = theme === "custom" 
    ? { primary: customColor, bg: `${customColor}05`, border: `${customColor}20`, text: "#1A202C", accent: customColor, card: "#FFFFFF", input: "#FFFFFF", isDark: false }
    : (THEMES[theme as keyof typeof THEMES] || THEMES.golden);

  // Fetch IP
  useEffect(() => {
    const fetchIp = async () => {
      try {
        const res = await fetch("https://api.ipify.org?format=json");
        const data = await res.json();
        setUserIp(data.ip);
      } catch {
        setUserIp("127.0.0.1");
      }
    };
    fetchIp();
  }, []);

  // Initialize SW for Ultraviolet
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/uv/sw.js", {
        scope: "/uv/service/",
      }).then((reg) => {
        console.log("CorgiProxy SW Registered");
        // Check if actually ready
        if (reg.active) {
            setIsProxyReady(true);
        } else {
            reg.addEventListener('updatefound', () => {
                const installingWorker = reg.installing;
                if (installingWorker) {
                    installingWorker.onstatechange = () => {
                        if (installingWorker.state === 'activated') {
                            setIsProxyReady(true);
                        }
                    };
                }
            });
        }
      }).catch(err => {
        console.error("SW Registration failed:", err);
        setIsProxyReady(false);
      });

      // Fallback check
      navigator.serviceWorker.ready
        .then(() => setIsProxyReady(true))
        .catch(err => console.error("SW Ready check failed:", err));
    }
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    let targetUrl = searchQuery.trim();
    if (!targetUrl.startsWith("http") && !targetUrl.startsWith("/") && !targetUrl.startsWith("./")) {
      if (targetUrl.includes(".") && !targetUrl.includes(" ")) {
        targetUrl = "https://" + targetUrl;
      } else {
        targetUrl = "https://duckduckgo.com/?q=" + encodeURIComponent(targetUrl);
      }
    }

    if (targetUrl.startsWith("/") || targetUrl.startsWith("./")) {
      const path = targetUrl;
      const name = targetUrl.split('/').pop()?.split('.')[0] || targetUrl;
      
      const newTabId = Math.random().toString(36).substr(2, 9);
      const newTab = { id: newTabId, url: path, title: name, isLoading: true };
      setTabs(prev => [...prev, newTab]);
      setActiveTabId(newTabId);
      
      setIsLoading(true);
      setProxyUrl(path);
      setCurrentTitle(name);
      setActiveTab("proxy");
      return;
    }

    // @ts-ignore
    if (typeof __uv$config === 'undefined') {
       alert("Patience, pup! The browser engine is still warming up. Try again in a second.");
       return;
    }

    // @ts-ignore
    const encoded = __uv$config.encodeUrl(targetUrl);
    const finalUrl = `/uv/service/${encoded}`;
    
    const newTabId = Math.random().toString(36).substr(2, 9);
    const newTab = { id: newTabId, url: finalUrl, title: targetUrl, isLoading: true };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTabId);

    setIsLoading(true);
    setProxyUrl(finalUrl);
    setCurrentTitle(targetUrl);
    setActiveTab("proxy");

    setHistory(prev => {
      const filtered = prev.filter(h => h.url !== targetUrl);
      return [{ url: targetUrl, time: Date.now() }, ...filtered].slice(0, 10);
    });
  };

  const createNewTab = (url: string = "https://google.com", title: string = "New Tab") => {
    let finalUrl = url;
    if (url.startsWith("http")) {
      // @ts-ignore
      if (typeof __uv$config === 'undefined') {
        alert("Barking engine still starting! Please wait a moment.");
        return;
      }
      // @ts-ignore
      const encoded = __uv$config.encodeUrl(url);
      finalUrl = `/uv/service/${encoded}`;
    }
    
    const newTabId = Math.random().toString(36).substr(2, 9);
    const newTab = { id: newTabId, url: finalUrl, title: title, isLoading: true };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newTabId);
    setProxyUrl(finalUrl);
    setCurrentTitle(title);
    setIsLoading(true);
    setActiveTab("proxy");
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTabId === id) {
      if (newTabs.length > 0) {
        const nextTab = newTabs[newTabs.length - 1];
        setActiveTabId(nextTab.id);
        setProxyUrl(nextTab.url);
        setCurrentTitle(nextTab.title);
      } else {
        setActiveTabId(null);
        setProxyUrl(null);
        setActiveTab("home");
      }
    }
  };

  const switchToTab = (id: string) => {
     const tab = tabs.find(t => t.id === id);
     if (tab) {
       setActiveTabId(id);
       setProxyUrl(tab.url);
       setCurrentTitle(tab.title);
       setBrowserSearchQuery(tab.title);
     }
  };

  const handleBrowserSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!browserSearchQuery.trim()) return;

    let targetUrl = browserSearchQuery.trim();
    if (!targetUrl.startsWith("http") && !targetUrl.startsWith("/") && !targetUrl.startsWith("./")) {
      if (targetUrl.includes(".") && !targetUrl.includes(" ")) {
        targetUrl = "https://" + targetUrl;
      } else {
        targetUrl = "https://duckduckgo.com/?q=" + encodeURIComponent(targetUrl);
      }
    }

    let finalUrl = targetUrl;
    if (targetUrl.startsWith("http")) {
       // @ts-ignore
       const encoded = __uv$config.encodeUrl(targetUrl);
       finalUrl = `/uv/service/${encoded}`;
    }

    if (activeTabId) {
       // Force a refresh even if same URL
       if (proxyUrl === finalUrl) {
           reloadIframe();
       }
       setTabs(prev => prev.map(t => t.id === activeTabId ? { ...t, url: finalUrl, title: targetUrl, isLoading: true } : t));
       setProxyUrl(finalUrl);
       setCurrentTitle(targetUrl);
       setIsLoading(true);
    } else {
       createNewTab(targetUrl, targetUrl);
    }
  };

  const openGame = (path: string, name: string) => {
     const newTabId = Math.random().toString(36).substr(2, 9);
     const newTab = { id: newTabId, url: path, title: name, isLoading: true };
     setTabs(prev => [...prev, newTab]);
     setActiveTabId(newTabId);
     
     // setIsLoading(true);
     setProxyUrl(path);
     setCurrentTitle(name);
     setActiveTab("proxy");
     
     // Update played history
     const game = GAMES.find(g => g.name === name);
     if (game) {
       setPlayedHistory(prev => {
         const filtered = prev.filter(id => id !== game.id);
         return [game.id, ...filtered].slice(0, 8);
       });
     }
  };

  const reloadIframe = () => {
    if (iframeRef.current) {
      setIsLoading(true);
      // More robust reload that triggers onLoad
      const currentSrc = iframeRef.current.src;
      iframeRef.current.src = 'about:blank';
      setTimeout(() => {
        if (iframeRef.current) iframeRef.current.src = currentSrc;
      }, 10);
    }
  };

  if (authStatus === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: currentTheme.bg }}>
        <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ repeat: Infinity, duration: 2 }}>
          <Dog size={64} style={{ color: currentTheme.primary }} />
        </motion.div>
      </div>
    );
  }

  if (authStatus === "unauthenticated") {
    return (
      <AuthScreen 
        theme={currentTheme} 
        onAuth={(user, isGuest) => {
          if (isGuest) {
            setAuthStatus("guest");
            localStorage.setItem("corgi-session", "guest");
          } else {
            setCurrentUser(user);
            setAuthStatus("authenticated");
            localStorage.setItem("corgi-session", JSON.stringify(user));
          }
        }} 
      />
    );
  }

  return (
    <div 
      className="min-h-screen transition-colors duration-500 font-sans selection:bg-[#FF9F00] selection:text-white"
      style={{ 
        backgroundColor: currentTheme.bg, 
        color: currentTheme.text,
        backgroundImage: pattern === "bones" ? `url("data:image/svg+xml,%3Csvg width='80' height='80' viewBox='0 0 80 80' xmlns='http://www.w3.org/2000/svg'%3E%3Ctext x='10' y='30' font-size='20' opacity='${currentTheme.isDark ? '0.15' : '0.08'}'%3E🐾%3C/text%3E%3Ctext x='50' y='70' font-size='20' opacity='${currentTheme.isDark ? '0.15' : '0.08'}'%3E🦴%3C/text%3E%3C/svg%3E")` : 'none'
      }}
    >
      {/* Navigation Rail / Tab Bar (Mobile Bottom, Desktop Side) */}
      <nav 
        className="fixed bottom-6 left-1/2 -translate-x-1/2 backdrop-blur-md px-6 py-3 rounded-full flex items-center gap-8 shadow-xl z-50 transition-all"
        style={{ 
          borderColor: currentTheme.border, 
          borderWidth: '2px', 
          backgroundColor: `${currentTheme.card}${currentTheme.isDark ? 'CC' : '99'}`
        }}
      >
        <NavButton active={activeTab === "home"} onClick={() => { playSound("click"); setActiveTab("home"); }} icon={<Home size={22} />} label="Home" themeColor={currentTheme.primary} />
        <NavButton active={activeTab === "games"} onClick={() => { playSound("click"); setActiveTab("games"); }} icon={<Gamepad2 size={22} />} label="Stash" themeColor={currentTheme.primary} />
        <NavButton active={activeTab === "settings"} onClick={() => { playSound("click"); setActiveTab("settings"); }} icon={<Settings size={22} />} label="PawConfig" themeColor={currentTheme.primary} />
      </nav>

      <main className="container mx-auto px-4 pt-8 pb-32">
        <AnimatePresence mode="wait">
          {activeTab === "home" && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center text-center space-y-12"
            >
              <div className="relative group">
                <motion.div 
                  animate={{ rotate: [0, -5, 5, 0] }} 
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className="p-6 rounded-[2.5rem] shadow-2xl transition-colors duration-500"
                  style={{ backgroundColor: currentTheme.primary, boxShadow: `0 25px 50px -12px ${currentTheme.primary}33` }}
                >
                  <Dog size={80} className="text-white" />
                </motion.div>
                <div 
                  className="absolute -top-4 -right-4 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg"
                  style={{ backgroundColor: currentTheme.accent }}
                >
                  Unblocked
                </div>
              </div>

              <div className="space-y-4">
                <h1 className="text-6xl font-black tracking-tight" style={{ color: currentTheme.text }}>
                  Corgi<span style={{ color: currentTheme.primary }}>Stash</span>
                </h1>
                <p className="text-xl max-w-md mx-auto leading-relaxed opacity-80">
                  The fluffiest web proxy and game stash. Bark through filters and sploot in the sandbox.
                </p>
                <p className="text-xs font-bold opacity-30 mt-[-1rem]" style={{ color: currentTheme.text }}>
                  Note: some games or things might not work - sky
                </p>
              </div>

              <form 
                onSubmit={handleSearch} 
                className="w-full max-w-2xl relative"
                onFocus={() => setShowHomeSuggestions(true)}
                onBlur={() => setTimeout(() => setShowHomeSuggestions(false), 200)}
              >
                <input
                  type="text"
                  placeholder={isProxyReady ? "Search with DuckDuckGo or enter URL..." : "Waking up the puppies... (Proxy starting)"}
                  disabled={!isProxyReady}
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setHomeSuggestionIndex(-1);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "ArrowDown") {
                      setHomeSuggestionIndex(prev => Math.min(prev + 1, homeSuggestions.length - 1));
                    } else if (e.key === "ArrowUp") {
                      setHomeSuggestionIndex(prev => Math.max(prev - 1, -1));
                    } else if (e.key === "Enter" && homeSuggestionIndex >= 0) {
                      e.preventDefault();
                      const suggestion = homeSuggestions[homeSuggestionIndex];
                      if (suggestion.type === 'game') {
                        openGame(suggestion.path, suggestion.name);
                      } else {
                        setSearchQuery(suggestion.url);
                        // Trigger search slightly after setting state
                        setTimeout(() => {
                          const fakeEvent = { preventDefault: () => {} } as React.FormEvent;
                          handleSearch(fakeEvent);
                        }, 10);
                      }
                      setShowHomeSuggestions(false);
                    }
                  }}
                  className={`w-full border-4 rounded-3xl px-16 py-6 pb-8 text-xl shadow-2xl focus:ring-0 outline-none transition-all placeholder:opacity-50 ${!isProxyReady ? 'opacity-50 cursor-wait' : ''}`}
                  style={{ 
                    borderRadius: '40px 40px 20px 20px', 
                    borderColor: currentTheme.border,
                    backgroundColor: currentTheme.input,
                    color: currentTheme.text
                  }}
                />
                
                {/* Suggestions Dropdown */}
                <AnimatePresence>
                  {showHomeSuggestions && homeSuggestions.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute left-[2px] right-[2px] top-full mt-[-2.5rem] p-2 rounded-b-[2.5rem] border-x-4 border-b-4 shadow-2xl z-40 overflow-hidden"
                      style={{ 
                        borderColor: currentTheme.border, 
                        backgroundColor: currentTheme.card,
                      }}
                    >
                      <div className="flex flex-col">
                        {homeSuggestions.map((item, idx) => (
                          <button
                            key={item.type === 'game' ? `game-${item.id}` : `site-${item.name}`}
                            type="button"
                            onClick={() => {
                              playSound("launch");
                              if (item.type === 'game') {
                                openGame(item.path, item.name);
                              } else {
                                setSearchQuery(item.url);
                                setTimeout(() => handleSearch({ preventDefault: () => {} } as any), 10);
                              }
                              setShowHomeSuggestions(false);
                            }}
                            onMouseEnter={() => setHomeSuggestionIndex(idx)}
                            className="flex items-center gap-4 p-4 rounded-2xl transition-all text-left group"
                            style={{ 
                              backgroundColor: homeSuggestionIndex === idx ? `${currentTheme.primary}15` : 'transparent'
                            }}
                          >
                            <div className="w-12 h-12 rounded-xl overflow-hidden shadow-sm flex-shrink-0 flex items-center justify-center bg-gray-100/50">
                              {item.type === 'game' ? (
                                <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              ) : (
                                <Search size={20} className="opacity-40" style={{ color: currentTheme.primary }} />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-bold truncate" style={{ color: homeSuggestionIndex === idx ? currentTheme.primary : currentTheme.text }}>
                                {item.name}
                              </p>
                              <p className="text-[10px] uppercase tracking-widest font-black opacity-30">
                                {item.type === 'game' ? `Buried treasure • ${item.category}` : 'Quick Destination'}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              {item.type === 'site' && <span className="text-[9px] font-mono opacity-20 hidden sm:block truncate max-w-[120px]">{item.url}</span>}
                              <Play size={16} className={`transition-all ${homeSuggestionIndex === idx ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-2'}`} style={{ color: currentTheme.primary }} />
                            </div>
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[90%] h-4 rounded-t-full opacity-20" style={{ backgroundColor: currentTheme.primary }} />
                <Search className="absolute left-6 top-7 text-[#C5B4A3]" size={28} />
                <button 
                  type="submit" 
                  className="absolute right-4 top-4 text-white p-3 rounded-2xl hover:scale-105 active:scale-95 transition-transform"
                  style={{ backgroundColor: currentTheme.primary }}
                  onClick={() => playSound("click")}
                >
                  <ArrowRight size={24} />
                </button>
              </form>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 w-full max-w-4xl">
                {QUICK_SITES.map((site) => (
                  <button 
                    key={site.name} 
                    onClick={() => {
                        if (site.url.startsWith("http")) {
                            createNewTab(site.url, site.name);
                        } else {
                            openGame(site.url, site.name);
                        }
                    }}
                    className="p-3 rounded-2xl border-2 transition-all flex flex-col items-center gap-1.5 group shadow-sm hover:scale-105 active:scale-95"
                    style={{ 
                      borderColor: site.name === "DuckDuckGo" ? currentTheme.primary : currentTheme.border, 
                      backgroundColor: currentTheme.card 
                    }}
                  >
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center transition-colors" style={{ backgroundColor: `${currentTheme.primary}10` }}>
                      {site.url.startsWith("http") ? <ExternalLink size={16} className="opacity-50 group-hover:opacity-100" style={{ color: currentTheme.primary }} /> : <Search size={16} className="opacity-50 group-hover:opacity-100" style={{ color: currentTheme.primary }} />}
                    </div>
                    <span className="font-bold text-xs" style={{ color: currentTheme.text }}>{site.name}</span>
                  </button>
                ))}
              </div>

              {/* Browser Launcher Info (WIP) */}
              <div className="flex flex-col items-center gap-4 py-8">
                 <div 
                    className="group relative px-8 py-4 rounded-2xl bg-gray-100 border-4 font-black uppercase tracking-widest text-sm flex items-center gap-3 transition-all shadow-xl"
                    style={{ borderColor: currentTheme.border, color: currentTheme.text }}
                 >
                    <Dog size={20} style={{ color: currentTheme.primary }} />
                    Sorry, this is in work in progress. Expect it in the future updates - sky
                 </div>
              </div>

              {history.length > 0 && (
                <div className="w-full max-w-2xl text-left space-y-4">
                   <div className="flex items-center justify-between px-4">
                      <h3 className="text-xs font-black opacity-30 uppercase tracking-[0.2em]">Recent Barks</h3>
                      <button 
                        onClick={() => {setHistory([]); localStorage.removeItem("corgi-history");}}
                        className="text-[10px] font-bold opacity-30 hover:opacity-100 transition-all uppercase tracking-widest hover:text-red-500"
                      >
                        Clear All
                      </button>
                   </div>
                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                     {history.slice(0, 4).map((h) => (
                        <button 
                          key={h.time}
                          onClick={() => {setSearchQuery(h.url); setTimeout(() => handleSearch({ preventDefault: () => {} } as any), 0)}}
                          className="backdrop-blur-sm p-3 rounded-xl border border-transparent flex items-center gap-3 transition-all group overflow-hidden"
                          style={{ 
                            borderColor: `${currentTheme.border}60`,
                            backgroundColor: `${currentTheme.card}${currentTheme.isDark ? 'CC' : '80'}`
                          }}
                        >
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center shadow-sm flex-shrink-0" style={{ backgroundColor: currentTheme.isDark ? currentTheme.bg : '#FFFFFF' }}>
                            <Dog size={14} className="opacity-40" />
                          </div>
                          <div className="flex flex-col items-start min-w-0">
                            <span className="text-sm font-medium truncate w-full opacity-70 group-hover:opacity-100">{h.url.replace(/^https?:\/\//, '')}</span>
                            <span className="text-[10px] opacity-30 group-hover:opacity-60">{formatRelativeTime(h.time)}</span>
                          </div>
                        </button>
                     ))}
                   </div>
                </div>
               )}
            </motion.div>
          )}
          {activeTab === "games" && (
            <motion.div
              key="games"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <AnimatePresence>
                {showThumbnailNote && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div 
                      className="p-6 rounded-[2.5rem] border-4 flex items-center justify-between gap-6 shadow-[0_20px_50px_rgba(0,0,0,0.3)] mb-10 relative group overflow-hidden"
                      style={{ 
                        backgroundColor: `${currentTheme.primary}20`, 
                        borderColor: currentTheme.primary,
                        color: currentTheme.text 
                      }}
                    >
                      <motion.div 
                        animate={{ scale: [1, 1.05, 1], rotate: [-1, 1, -1] }} 
                        transition={{ repeat: Infinity, duration: 4 }}
                        className="flex items-center gap-4 relative z-10"
                      >
                        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-[0_0_20px_rgba(0,0,0,0.2)]" style={{ backgroundColor: currentTheme.primary }}>
                          <Dog size={32} />
                        </div>
                        <div className="flex flex-col">
                          <p className="font-black text-lg uppercase tracking-tighter leading-none mb-1">Attention Alpha!</p>
                          <p className="font-bold text-base opacity-90">Ill be adding a thumbnail later to all of the games. - sky</p>
                        </div>
                      </motion.div>
                      <button 
                        onClick={() => setShowThumbnailNote(false)}
                        className="p-3 hover:bg-black/10 rounded-2xl transition-all hover:scale-110 active:scale-95 relative z-10"
                      >
                        <X size={24} className="opacity-50" />
                      </button>
                      <div className="absolute -top-3 -left-3 px-4 py-2 bg-red-500 text-white text-xs font-black uppercase tracking-widest rounded-xl rotate-[-5deg] shadow-xl z-20 animate-bounce">
                        Bark Alert!
                      </div>
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-5 rounded-full -translate-y-1/2 translate-x-1/2" />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div className="space-y-1">
                  <h2 className="text-4xl font-black italic tracking-tight" style={{ fontFamily: '"Space Grotesk", sans-serif' }}>GAME STASH</h2>
                  <p className="opacity-70 font-medium">Buried treasures from the local park.</p>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto items-center">
                  <div 
                    className="relative w-full sm:w-64 group"
                    onFocus={() => setShowGameSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowGameSuggestions(false), 200)}
                  >
                    <input 
                      type="text" 
                      placeholder="Search buried treasures..."
                      value={gameSearchQuery}
                      onChange={(e) => {
                        setGameSearchQuery(e.target.value);
                        setGameSuggestionIndex(-1);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "ArrowDown") {
                          setGameSuggestionIndex(prev => Math.min(prev + 1, gameSuggestions.length - 1));
                        } else if (e.key === "ArrowUp") {
                          setGameSuggestionIndex(prev => Math.max(prev - 1, -1));
                        } else if (e.key === "Enter" && gameSuggestionIndex >= 0) {
                          const game = gameSuggestions[gameSuggestionIndex];
                          playSound("launch");
                          openGame(game.path, game.name);
                          setShowGameSuggestions(false);
                        }
                      }}
                      className="w-full border-4 rounded-2xl px-12 py-3 text-sm font-bold focus:ring-0 outline-none transition-all shadow-lg"
                      style={{ 
                        borderColor: currentTheme.border, 
                        backgroundColor: currentTheme.input, 
                        color: currentTheme.text,
                        borderRadius: '20px 20px 10px 10px'
                      }}
                    />
                    <Search className="absolute left-4 top-4 opacity-30 group-focus-within:opacity-100 transition-opacity" size={20} />
                    
                    {/* Game Stash Suggestions */}
                    <AnimatePresence>
                      {showGameSuggestions && gameSuggestions.length > 0 && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          className="absolute left-0 right-0 top-full mt-[-4px] p-2 rounded-b-2xl border-x-4 border-b-4 shadow-2xl z-40 overflow-hidden"
                          style={{ 
                            borderColor: currentTheme.border, 
                            backgroundColor: currentTheme.card,
                          }}
                        >
                          <div className="flex flex-col">
                            {gameSuggestions.map((game, idx) => (
                              <button
                                key={game.id}
                                onClick={() => {
                                  playSound("launch");
                                  openGame(game.path, game.name);
                                  setShowGameSuggestions(false);
                                }}
                                onMouseEnter={() => setGameSuggestionIndex(idx)}
                                className="flex items-center gap-3 p-3 rounded-xl transition-all text-left"
                                style={{ 
                                  backgroundColor: gameSuggestionIndex === idx ? `${currentTheme.primary}15` : 'transparent'
                                }}
                              >
                                <div className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0 shadow-sm border border-gray-100">
                                  <img src={game.image} alt={game.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-xs font-bold truncate" style={{ color: gameSuggestionIndex === idx ? currentTheme.primary : currentTheme.text }}>
                                    {game.name}
                                  </p>
                                  <p className="text-[9px] uppercase tracking-widest opacity-40 font-black">{game.category}</p>
                                </div>
                              </button>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    {gameSearchQuery && (
                      <button 
                        onClick={() => setGameSearchQuery("")}
                        className="absolute right-4 top-4 opacity-30 hover:opacity-100"
                      >
                        <X size={18} />
                      </button>
                    )}
                  </div>
                  <div className="flex gap-2 text-[10px] font-black uppercase tracking-[0.2em] px-5 py-4 rounded-2xl border-2 whitespace-nowrap shadow-md" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.card }}>
                    <span style={{ color: currentTheme.primary }}>{GAMES.filter(g => g.name.toLowerCase().includes(gameSearchQuery.toLowerCase())).length}</span>
                    <span className="opacity-30">/</span>
                    <span>{GAMES.length}</span>
                  </div>
                  <button
                    onClick={() => { playSound("click"); setSortOrder(prev => prev === "default" ? "az" : "default"); }}
                    className="flex items-center gap-2 px-5 py-4 rounded-2xl border-2 font-black text-[10px] uppercase tracking-[0.2em] shadow-md transition-all hover:scale-105 active:scale-95"
                    style={{ 
                      borderColor: sortOrder === "az" ? currentTheme.primary : currentTheme.border, 
                      backgroundColor: currentTheme.card,
                      color: sortOrder === "az" ? currentTheme.primary : currentTheme.text
                    }}
                  >
                    <ArrowDownAZ size={16} />
                    <span className="hidden sm:inline">{sortOrder === "az" ? "Sorted A-Z" : "Sort A-Z"}</span>
                  </button>
                </div>
              </div>

              {/* Category Filter */}
              {!gameSearchQuery && (
                <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar">
                  {["All", ...Array.from(new Set(GAMES.map(g => g.category)))].map(cat => (
                    <button
                      key={cat}
                      onClick={() => { playSound("click"); setSelectedCategory(cat); }}
                      className={`px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest transition-all border-4 shadow-sm hover:scale-105 active:scale-95 whitespace-nowrap ${selectedCategory === cat ? 'border-primary' : 'border-transparent hover:border-gray-200 opacity-60 hover:opacity-100'}`}
                      style={{ 
                        backgroundColor: selectedCategory === cat ? currentTheme.primary : currentTheme.card,
                        color: selectedCategory === cat ? '#FFF' : currentTheme.text,
                        borderColor: selectedCategory === cat ? currentTheme.primary : 'transparent'
                      }}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              )}

              {playedHistory.length > 0 && !gameSearchQuery && selectedCategory === "All" && (
                <div className="space-y-4">
                   <div className="flex items-center gap-3">
                      <div className="w-2 h-6 rounded-full" style={{ backgroundColor: currentTheme.primary }} />
                      <h3 className="text-xs font-black opacity-30 uppercase tracking-[0.2em]">Recently Splooted</h3>
                   </div>
                   <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                      {playedHistory.map(id => {
                        const game = GAMES.find(g => g.id === id);
                        if (!game) return null;
                        return (
                          <div 
                            key={`hist-${game.id}`}
                            onClick={() => { playSound("launch"); openGame(game.path, game.name); }}
                            className="flex-shrink-0 w-48 relative group cursor-pointer"
                          >
                             <div className="aspect-video rounded-2xl overflow-hidden border-2 shadow-md group-hover:shadow-xl transition-all" style={{ borderColor: currentTheme.border }}>
                                <img src={game.image} alt={game.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" referrerPolicy="no-referrer" />
                             </div>
                             <p className="mt-2 text-xs font-bold truncate group-hover:text-primary transition-colors" style={{ color: currentTheme.text }}>{game.name}</p>
                          </div>
                        );
                      })}
                   </div>
                </div>
              )}

              {favorites.length > 0 && !gameSearchQuery && selectedCategory === "All" && (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                      <div className="w-2 h-6 rounded-full" style={{ backgroundColor: currentTheme.primary }} />
                      <h3 className="text-xs font-black opacity-30 uppercase tracking-[0.2em]">Favorite Treasures</h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {GAMES.filter(g => favorites.includes(g.id)).map((game) => (
                      <GameCard 
                        key={`fav-${game.id}`} 
                        game={game} 
                        currentTheme={currentTheme} 
                        isFavorite={true}
                        onToggleFavorite={(e) => toggleFavorite(game.id, e)}
                        onPlay={() => { playSound("launch"); openGame(game.path, game.name); }}
                        onHover={() => playSound("hover")}
                      />
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                    <div className="w-2 h-6 rounded-full" style={{ backgroundColor: currentTheme.primary }} />
                    <h3 className="text-xs font-black opacity-30 uppercase tracking-[0.2em]">
                      {gameSearchQuery ? `Search Results for "${gameSearchQuery}"` : (selectedCategory === "All" ? "The Full Stash" : `${selectedCategory} Games`)}
                    </h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {GAMES.filter(g => 
                    g.name.toLowerCase().includes(gameSearchQuery.toLowerCase()) && 
                    (selectedCategory === "All" || g.category === selectedCategory)
                  )
                  .sort((a, b) => {
                    if (sortOrder === "az") return a.name.localeCompare(b.name);
                    return 0; // Maintain default order
                  })
                  .map((game) => (
                    <GameCard 
                      key={game.id} 
                      game={game} 
                      currentTheme={currentTheme} 
                      isFavorite={favorites.includes(game.id)}
                      onToggleFavorite={(e) => toggleFavorite(game.id, e)}
                      onPlay={() => { playSound("launch"); openGame(game.path, game.name); }}
                      onHover={() => playSound("hover")}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "proxy" && proxyUrl && (
            <motion.div
              key="proxy"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`fixed inset-0 z-[60] flex flex-col transition-all duration-500 ${isTheaterMode ? 'p-10 bg-black/90 backdrop-blur-2xl' : 'bg-white'}`}
            >
              {/* Browser Header */}
              <div 
                className={`border-b-4 flex flex-col transition-all duration-500 overflow-hidden ${isTheaterMode ? 'rounded-t-[2.5rem] mt-4 mx-4' : ''}`}
                style={{ backgroundColor: currentTheme.bg, borderColor: currentTheme.border }}
              >
                {/* Tab Bar */}
                <div className="flex items-center gap-1 px-4 pt-4 overflow-x-auto no-scrollbar scroll-smooth">
                   {tabs.map((tab) => (
                     <motion.div
                       layout
                       key={tab.id}
                       onClick={() => switchToTab(tab.id)}
                       className={`relative group flex items-center gap-3 px-6 py-3 rounded-t-2xl min-w-[150px] max-w-[220px] cursor-pointer transition-all border-x-2 border-t-2 ${activeTabId === tab.id ? 'z-10 bg-white' : 'bg-black/5 opacity-60 hover:opacity-100'}`}
                       style={{ 
                         borderColor: activeTabId === tab.id ? currentTheme.border : 'transparent',
                         backgroundColor: activeTabId === tab.id ? currentTheme.card : undefined
                       }}
                     >
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                           <Dog size={14} style={{ color: activeTabId === tab.id ? currentTheme.primary : 'gray' }} />
                           <span className="text-[10px] font-black uppercase tracking-widest truncate" style={{ color: currentTheme.text }}>{tab.title}</span>
                        </div>
                        <button 
                          onClick={(e) => closeTab(tab.id, e)}
                          className="w-5 h-5 rounded-full flex items-center justify-center hover:bg-red-500 hover:text-white transition-colors"
                        >
                          <X size={12} />
                        </button>
                        {activeTabId === tab.id && (
                          <div className="absolute -bottom-1 left-0 right-0 h-2 bg-white z-20" style={{ backgroundColor: currentTheme.card }} />
                        )}
                     </motion.div>
                   ))}
                   <button 
                    onClick={() => createNewTab()}
                    className="p-3 mb-1 rounded-full hover:bg-black/5 transition-all text-gray-400 hover:text-primary"
                   >
                     <Plus size={20} />
                   </button>
                </div>

                <div 
                  className="p-3 flex items-center gap-4 border-t-2 relative z-10 bg-inherit"
                  style={{ borderColor: currentTheme.border }}
                >
                  <div className="flex items-center gap-2">
                    <ControlButton themeColor={currentTheme.primary} icon={<ArrowLeft size={18} />} onClick={() => { playSound("click"); window.history.back(); }} />
                    <ControlButton themeColor={currentTheme.primary} icon={<RotateCw size={18} />} onClick={() => { playSound("click"); reloadIframe(); }} />
                    <ControlButton themeColor={currentTheme.primary} icon={<Home size={18} />} onClick={() => { playSound("click"); setActiveTab("home"); setIsTheaterMode(false); }} />
                  </div>
                  
                  <form 
                    onSubmit={handleBrowserSearch}
                    className="flex-1 border-4 rounded-2xl px-4 py-2 flex items-center justify-between text-sm shadow-inner transition-colors duration-500 overflow-hidden"
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.input }}
                  >
                     <div className="flex items-center gap-3 flex-1 min-w-0">
                        <Dog size={16} style={{ color: currentTheme.primary }} className="flex-shrink-0" />
                        <input 
                          type="text"
                          value={browserSearchQuery}
                          onChange={(e) => setBrowserSearchQuery(e.target.value)}
                          className="bg-transparent border-none outline-none w-full font-black uppercase tracking-widest text-[11px] truncate"
                          style={{ color: currentTheme.text }}
                          placeholder="Bark for a site or URL..."
                        />
                     </div>
                     <div className="flex items-center gap-4 flex-shrink-0 ml-2">
                        <button type="submit" className="hidden" />
                      <button 
                        onClick={() => setIsTheaterMode(!isTheaterMode)}
                        className={`hidden sm:flex items-center gap-2 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${isTheaterMode ? 'bg-primary text-white shadow-lg scale-105' : 'hover:bg-black/5 opacity-50'}`}
                        style={{ backgroundColor: isTheaterMode ? currentTheme.primary : undefined }}
                      >
                        <Maximize2 size={12} />
                        Theater Mode
                      </button>
                      <button 
                         onClick={() => {
                            if (document.fullscreenElement) {
                              document.exitFullscreen();
                            } else {
                              document.documentElement.requestFullscreen();
                            }
                         }}
                         className="p-1 hover:scale-110 transition-transform opacity-50 hover:opacity-100"
                         style={{ color: currentTheme.primary }}
                      >
                         <Maximize2 size={16} />
                      </button>
                      <span 
                        className="hidden md:block text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border-2 transition-colors"
                        style={{ backgroundColor: `${currentTheme.primary}10`, borderColor: `${currentTheme.primary}20`, color: currentTheme.primary }}
                      >
                        {userIp}
                      </span>
                   </div>
                </form>

                <div className="flex items-center gap-3">
                   <button 
                    onClick={() => {
                      setProxyUrl(null); 
                      setActiveTab("home"); 
                      setIsTheaterMode(false);
                      if (!hasReviewed) {
                        setShowReviewModal(true);
                      }
                    }} 
                    className="w-10 h-10 rounded-2xl flex items-center justify-center hover:scale-110 transition-all shadow-xl text-white border-b-4 active:border-b-0 active:translate-y-1"
                    style={{ backgroundColor: currentTheme.accent, borderColor: `${currentTheme.accent}88` }}
                   >
                     <X size={20} strokeWidth={3} />
                   </button>
                </div>
              </div>
            </div>
              <div className={`flex-1 w-full h-full relative overflow-hidden transition-all duration-500 bg-white ${isTheaterMode ? 'rounded-b-[2.5rem] mb-4 mx-4 border-x-4 border-b-4' : ''}`} style={{ borderColor: isTheaterMode ? currentTheme.border : 'transparent' }}>
                <AnimatePresence>
                  {(!isProxyReady || isLoading) && (
                    <motion.div 
                      key="proxy-loader"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="absolute inset-0 z-10 flex items-center justify-center transition-colors duration-500"
                      style={{ backgroundColor: currentTheme.bg }}
                    >
                      <div className="flex flex-col items-center space-y-8 w-full max-w-sm px-6">
                         <div className="relative">
                            <motion.div 
                              animate={{ 
                                scale: [1, 1.1, 1],
                                rotate: [0, 5, -5, 0],
                                y: [0, -15, 0]
                              }}
                              transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                              className="p-10 rounded-[3rem] border-8 shadow-2xl relative z-20"
                              style={{ backgroundColor: currentTheme.card, borderColor: currentTheme.primary }}
                            >
                               <Dog size={80} style={{ color: currentTheme.primary }} />
                            </motion.div>
                            
                            {/* Pulsing rings around the dog */}
                            {[1, 2, 3].map((i) => (
                              <motion.div
                                key={i}
                                initial={{ scale: 0.8, opacity: 0.5 }}
                                animate={{ scale: 2, opacity: 0 }}
                                transition={{ repeat: Infinity, duration: 2, delay: i * 0.6 }}
                                className="absolute inset-0 rounded-[3rem] border-2 pointer-events-none"
                                style={{ borderColor: currentTheme.primary }}
                              />
                            ))}

                            <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex gap-3 z-30">
                               <motion.div animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0 }} className="w-3 h-3 rounded-full" style={{ backgroundColor: currentTheme.primary, boxShadow: `0 0 10px ${currentTheme.primary}` }} />
                               <motion.div animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.1 }} className="w-3 h-3 rounded-full" style={{ backgroundColor: currentTheme.primary, boxShadow: `0 0 10px ${currentTheme.primary}` }} />
                               <motion.div animate={{ y: [0, -10, 0], scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }} className="w-3 h-3 rounded-full" style={{ backgroundColor: currentTheme.primary, boxShadow: `0 0 10px ${currentTheme.primary}` }} />
                            </div>
                         </div>

                         <div className="w-full space-y-6 text-center">
                            <div className="space-y-2">
                               <motion.h2 
                                 key={currentLoadingMsg}
                                 initial={{ opacity: 0, y: 10 }}
                                 animate={{ opacity: 1, y: 0 }}
                                 className="text-2xl font-black uppercase tracking-tighter" 
                                 style={{ color: currentTheme.text }}
                               >
                                 {currentLoadingMsg}
                               </motion.h2>
                               <p className="opacity-50 text-sm font-bold italic">Fetching "{currentTitle}" treasure...</p>
                            </div>

                            {/* Progress Bar Container */}
                            <div className="w-full h-4 bg-gray-100 rounded-full overflow-hidden border-2 shadow-inner relative" style={{ borderColor: currentTheme.border }}>
                               <motion.div 
                                 className="h-full relative z-10"
                                 initial={{ width: "0%" }}
                                 animate={{ width: `${loadingProgress}%` }}
                                 transition={{ type: "spring", stiffness: 50, damping: 20 }}
                                 style={{ backgroundColor: currentTheme.primary }}
                               >
                                 {/* Animated shimmer effect on progress bar */}
                                 <motion.div 
                                   animate={{ x: ["-100%", "200%"] }}
                                   transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                                   className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
                                 />
                               </motion.div>
                               
                               {/* Background bone pattern in progress bar */}
                               <div className="absolute inset-0 opacity-10 flex items-center justify-around overflow-hidden pointer-events-none">
                                  {[...Array(6)].map((_, i) => (
                                    <Dog key={i} size={12} className="rotate-45" />
                                  ))}
                               </div>
                            </div>
                            
                            <div className="flex justify-between items-center px-1">
                               <p className="text-[10px] font-black uppercase tracking-widest opacity-40">Status: {loadingProgress < 100 ? 'Barking...' : 'Splooted!'}</p>
                               <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: currentTheme.primary }}>{Math.floor(loadingProgress)}%</p>
                            </div>
                         </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                {isProxyReady ? (
                  <iframe
                    key={proxyUrl || 'empty'}
                    ref={iframeRef}
                    src={proxyUrl || 'about:blank'}
                    className={`w-full h-full border-none transition-opacity duration-1000 ${isLoading ? 'opacity-0' : 'opacity-100'}`}
                    title="CorgiProxy Viewport"
                    onLoad={() => {
                      setTimeout(() => setIsLoading(false), proxyUrl?.startsWith("/games/") ? 1000 : 500);
                    }}
                  />
                ) : (
                  <div className="flex items-center justify-center w-full h-full text-gray-500">
                    <p>Waking up the proxy engine...</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "settings" && (
            <motion.div
              key="settings"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-2xl mx-auto space-y-8"
            >
              <h2 className="text-4xl font-bold flex items-center gap-4">
                <Settings size={32} /> PawConfig
              </h2>

              <div className="space-y-6">
                <SettingsGroup title="PawStyle (Theme)">
                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
                    {Object.entries(THEMES).map(([id, t]) => (
                      <button
                        key={id}
                        onClick={() => { playSound("click"); setTheme(id); }}
                        className={`p-4 rounded-2xl border-4 transition-all flex flex-col items-center gap-2 group ${theme === id ? 'border-primary' : 'border-transparent shadow-sm hover:border-gray-200'}`}
                        style={{ 
                          borderColor: theme === id ? currentTheme.primary : undefined,
                          backgroundColor: currentTheme.card 
                        }}
                      >
                         <div className="w-10 h-10 rounded-full shadow-inner" style={{ backgroundColor: t.primary }} />
                         <span className="text-xs font-bold capitalize">{id}</span>
                      </button>
                    ))}
                    
                    {/* Custom Color Picker */}
                    <div 
                      className={`p-4 rounded-2xl border-4 transition-all flex flex-col items-center gap-2 group relative overflow-hidden ${theme === 'custom' ? 'border-primary' : 'border-transparent shadow-sm hover:border-gray-200'}`}
                      style={{ 
                        borderColor: theme === 'custom' ? currentTheme.primary : undefined,
                        backgroundColor: currentTheme.card 
                      }}
                    >
                      <input 
                        type="color" 
                        value={customColor}
                        onChange={(e) => {
                          setCustomColor(e.target.value);
                          setTheme("custom");
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                      />
                      <div className="w-10 h-10 rounded-full shadow-inner border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden" style={{ backgroundColor: customColor }}>
                        {theme !== 'custom' && <div className="text-[10px] font-bold opacity-40">Pick</div>}
                      </div>
                      <span className="text-xs font-bold capitalize">Custom</span>
                    </div>
                  </div>
                </SettingsGroup>

                <SettingsGroup title="Background Pattern">
                  <div className="flex gap-4">
                    <button 
                      onClick={() => setPattern("none")}
                      className={`flex-1 p-4 rounded-2xl border-2 transition-all font-bold ${pattern === "none" ? 'border-primary' : 'border-transparent hover:opacity-80'}`}
                      style={{ 
                        borderColor: pattern === "none" ? currentTheme.primary : undefined,
                        backgroundColor: currentTheme.card
                      }}
                    >
                      Clean
                    </button>
                    <button 
                      onClick={() => setPattern("bones")}
                      className={`flex-1 p-4 rounded-2xl border-2 transition-all font-bold ${pattern === "bones" ? 'border-primary' : 'border-transparent hover:opacity-80'}`}
                      style={{ 
                        borderColor: pattern === "bones" ? currentTheme.primary : undefined,
                        backgroundColor: currentTheme.card
                      }}
                    >
                      Bones & Paws
                    </button>
                  </div>
                </SettingsGroup>

                <SettingsGroup title="Data Management">
                   <button 
                    onClick={() => {setHistory([]); localStorage.removeItem("corgi-history"); alert("History cleared!")}}
                    className="w-full p-4 rounded-2xl border-2 border-dashed transition-all font-bold hover:bg-white flex items-center justify-between group"
                    style={{ borderColor: currentTheme.border }}
                   >
                     <span>Clear Bark History</span>
                     <RotateCw size={18} className="opacity-40 group-hover:rotate-180 transition-transform duration-500" />
                   </button>
                </SettingsGroup>

                <SettingsGroup title="Proxy Engine">
                  <div className="flex items-center justify-between p-4 rounded-2xl border-2 transition-all" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.card }}>
                    <div className="space-y-1">
                      <p className="font-bold">Ultraviolet</p>
                      <p className="text-sm opacity-70">High-performance unblocking (XOR Mode)</p>
                    </div>
                    <div className="w-12 h-6 rounded-full relative" style={{ backgroundColor: currentTheme.primary }}>
                      <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full transition-all" />
                    </div>
                  </div>
                </SettingsGroup>

                <SettingsGroup title="Safety & Privacy">
                  <SettingsToggle label="Auto-Delete History" checked={true} themeColor={currentTheme.primary} borderColor={currentTheme.border} cardColor={currentTheme.card} />
                  <SettingsToggle label="Cloak Tab Title" checked={false} themeColor={currentTheme.primary} borderColor={currentTheme.border} cardColor={currentTheme.card} />
                </SettingsGroup>

                <SettingsGroup title="Pack Identity (Account)">
                   <div 
                    className="p-5 rounded-3xl border-2 flex flex-col gap-4 transition-all" 
                    style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.card }}
                   >
                     <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white" style={{ backgroundColor: currentTheme.primary }}>
                          <Dog size={24} />
                        </div>
                        <div className="flex-1">
                           <p className="font-black text-lg">{authStatus === "guest" ? "Solo Pup (Guest)" : currentUser?.username}</p>
                           <p className="text-xs opacity-50 uppercase tracking-widest font-bold">{authStatus === "guest" ? "No account linked" : "Alpha Pack Member"}</p>
                        </div>
                     </div>
                     <button 
                      onClick={handleLogout}
                      className="w-full py-3 rounded-2xl bg-red-500/10 text-red-500 font-bold hover:bg-red-500 hover:text-white transition-all border-2 border-red-500/20"
                     >
                       Leaf the Pack (Logout)
                     </button>
                   </div>
                </SettingsGroup>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Decorative Floating Corgi */}
      <motion.div
        animate={{ 
          y: [0, -10, 0],
          rotate: [0, 2, -2, 0]
        }}
        transition={{ repeat: Infinity, duration: 3 }}
        className="fixed bottom-10 right-10 pointer-events-none hidden md:block"
      >
        <div className="p-3 rounded-2xl border-2 shadow-lg flex items-center gap-3 transition-colors" style={{ borderColor: currentTheme.border, backgroundColor: currentTheme.card }}>
           <div className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors" style={{ backgroundColor: currentTheme.primary }}>
             <Dog size={20} className="text-white" />
           </div>
           <p className="text-xs font-bold whitespace-nowrap" style={{ color: currentTheme.text }}>Bark unblocked!</p>
        </div>
      </motion.div>

      {/* Review Modal */}
      <AnimatePresence>
        {showReviewModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="max-w-md w-full rounded-[3rem] p-10 shadow-2xl border-4 text-center space-y-8 relative overflow-hidden"
              style={{ 
                backgroundColor: currentTheme.card,
                borderColor: currentTheme.primary,
                color: currentTheme.text
              }}
            >
              <div className="absolute top-0 left-0 w-full h-2" style={{ backgroundColor: currentTheme.primary }} />
              
              <div className="flex flex-col items-center gap-4">
                <div 
                  className="w-20 h-20 rounded-3xl flex items-center justify-center text-white shadow-xl rotate-[-5deg]" 
                  style={{ backgroundColor: currentTheme.primary }}
                >
                  <Dog size={48} />
                </div>
                <h2 className="text-3xl font-black italic uppercase tracking-tighter" style={{ color: currentTheme.text }}>Rate the Stash!</h2>
                <p className="font-bold text-sm opacity-60">How many barks would you give Corgi Stash?</p>
              </div>

              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <button
                    key={i}
                    onMouseEnter={() => setHoverRating(i)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => {
                      playSound("launch");
                      setRating(i);
                    }}
                    className="p-2 transition-all transform hover:scale-125 hover:rotate-12"
                  >
                    <Dog 
                      size={40} 
                      className="transition-colors"
                      style={{ 
                        color: (hoverRating || rating) >= i ? currentTheme.primary : `${currentTheme.primary}20`,
                        fill: rating >= i ? currentTheme.primary : "none"
                      }}
                    />
                  </button>
                ))}
              </div>

              <p className="text-xs font-black uppercase tracking-widest opacity-60">
                {rating === 0 ? "Sniff around first..." : rating === 5 ? "MAXIMUM BARKS! WOOF!" : `${rating} Bones/Barks`}
              </p>

              <div className="flex flex-col gap-3">
                <button
                  disabled={rating === 0}
                  onClick={() => {
                    playSound("click");
                    setHasReviewed(true);
                    localStorage.setItem("corgi-reviewed", "true");
                    setShowReviewModal(false);
                  }}
                  className={`w-full py-4 rounded-2xl font-black text-lg transition-all shadow-lg active:scale-95 ${rating === 0 ? 'opacity-50 cursor-not-allowed text-white/50' : 'hover:scale-105 text-white'}`}
                  style={{ 
                    backgroundColor: rating === 0 ? (currentTheme.isDark ? '#334155' : '#cbd5e1') : currentTheme.primary
                  }}
                >
                  {rating === 0 ? "Pick some bones!" : "Submit Barks"}
                </button>
                <button
                  onClick={() => setShowReviewModal(false)}
                  className="text-xs font-bold opacity-50 hover:opacity-100 transition-opacity uppercase tracking-widest"
                >
                  Maybe later...
                </button>
              </div>

              <div className="absolute bottom-[-10px] right-[-10px] opacity-5">
                <Dog size={120} />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavButton({ active, onClick, icon, label, themeColor }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string; themeColor: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-all ${
        active ? "scale-110" : "opacity-40 hover:opacity-70"
      }`}
      style={{ color: active ? themeColor : undefined }}
    >
      <div className={`${active ? "p-2 rounded-xl" : ""}`} style={{ backgroundColor: active ? `${themeColor}15` : undefined }}>
        {icon}
      </div>
      <span className="text-[10px] font-bold uppercase tracking-wider">{label}</span>
    </button>
  );
}

function ControlButton({ icon, onClick, themeColor }: { icon: React.ReactNode; onClick: () => void; themeColor: string }) {
  return (
    <button 
      onClick={onClick}
      className="p-2 rounded-xl hover:bg-black/5 hover:shadow-md transition-all"
      style={{ color: themeColor }}
    >
      {icon}
    </button>
  );
}

interface GameCardProps {
  key?: React.Key;
  game: any;
  currentTheme: any;
  isFavorite: boolean;
  onToggleFavorite: (e: React.MouseEvent) => void;
  onPlay: () => void;
  onHover: () => void;
}

function GameCard({ game, currentTheme, isFavorite, onToggleFavorite, onPlay, onHover }: GameCardProps) {
  const isNew = game.id === "stumble-guys" || game.id === "rooftop-snipers" || game.id === "soccer-bros" || game.id === "snow-road" || game.id === "snow-rider-3d";

  return (
    <motion.div
      whileHover={{ y: -10, scale: 1.02 }}
      onMouseEnter={onHover}
      className={`rounded-[2rem] border-4 overflow-hidden group cursor-pointer shadow-xl hover:shadow-[0_20px_50px_rgba(0,0,0,0.15)] transition-all relative flex flex-col h-full`}
      style={{ 
        borderColor: currentTheme.border, 
        backgroundColor: currentTheme.card,
        boxShadow: `0 10px 30px -10px ${currentTheme.primary}20`
      }}
      onClick={onPlay}
    >
      <div className="h-44 bg-gray-100 relative overflow-hidden shrink-0">
        <img src={game.image} alt={game.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
        
        {/* Play Overlay */}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[2px]">
           <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-2xl scale-50 group-hover:scale-100 transition-transform duration-500">
              <Play size={24} fill={currentTheme.primary} className="ml-1" style={{ color: currentTheme.primary }} />
           </div>
        </div>

        {/* Favorite Button */}
        <motion.button 
          whileHover={{ scale: 1.1, rotate: 5 }}
          whileTap={{ scale: 0.9, rotate: -5 }}
          onClick={(e) => { e.stopPropagation(); onToggleFavorite(e); }}
          className="absolute top-4 right-4 p-2.5 rounded-2xl backdrop-blur-md transition-all z-20 shadow-lg border-2"
          style={{ 
            backgroundColor: isFavorite ? currentTheme.primary : 'rgba(255,255,255,0.9)',
            borderColor: isFavorite ? currentTheme.primary : 'white',
            color: isFavorite ? 'white' : currentTheme.primary
          }}
        >
          <motion.div
            initial={false}
            animate={isFavorite ? { scale: [1, 1.4, 1.2, 1] } : { scale: 1 }}
            transition={{ duration: 0.4, ease: "easeInOut" }}
          >
            <Heart 
              size={20} 
              fill={isFavorite ? "currentColor" : "none"} 
              strokeWidth={3} 
              className="drop-shadow-sm"
            />
          </motion.div>
        </motion.button>

        {/* Description Overlay (Slides down from top on hover) */}
        <div className="absolute inset-x-0 top-0 p-4 bg-black/80 backdrop-blur-md -translate-y-full group-hover:translate-y-0 transition-transform duration-300 z-10">
           <p className="text-[10px] text-white leading-relaxed font-medium text-center">
             {game.description || "No description available for this treasure yet."}
           </p>
        </div>

        {/* New Badge */}
        {isNew && (
          <div 
            className="absolute top-4 left-4 px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest text-white shadow-lg skew-x-[-10deg] z-20"
            style={{ backgroundColor: currentTheme.accent }}
          >
            Freshly Buried
          </div>
        )}

        {/* Category Badge */}
        <div className="absolute bottom-3 left-4 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[9px] font-black uppercase tracking-[0.2em] text-white/90 z-20">
           {game.category}
        </div>
      </div>

      <div className="p-5 flex flex-col gap-1 flex-1">
        <div className="flex justify-between items-start">
           <h4 className="font-black text-lg leading-tight truncate flex-1 uppercase" style={{ color: currentTheme.text, fontFamily: '"Space Grotesk", sans-serif' }}>
             {game.name}
           </h4>
        </div>
        <div className="flex items-center gap-2 mt-auto">
           <div className="w-2 h-2 rounded-full" style={{ backgroundColor: currentTheme.primary }} />
           <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest">Ready to play</p>
        </div>
      </div>

      {/* Decorative sploot curve */}
      <div 
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[60%] h-1.5 rounded-t-full opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ backgroundColor: currentTheme.primary }}
      />
    </motion.div>
  );
}

function SettingsGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <h3 className="text-xs font-black opacity-40 uppercase tracking-[0.2em]">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function SettingsToggle({ label, checked, themeColor, borderColor, cardColor }: { label: string; checked: boolean; themeColor: string; borderColor: string; cardColor: string }) {
  return (
    <div className="flex items-center justify-between p-4 rounded-2xl border-2 transition-all" style={{ borderColor, backgroundColor: cardColor }}>
      <span className="font-bold">{label}</span>
      <div className={`w-12 h-6 rounded-full relative transition-all`} style={{ backgroundColor: checked ? themeColor : (checked ? themeColor : '#cbd5e1') }}>
        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${checked ? 'right-1' : 'left-1'}`} />
      </div>
    </div>
  );
}

function AuthScreen({ theme, onAuth }: { theme: any; onAuth: (user: any, isGuest: boolean) => void }) {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username || !password) {
      setError("Bark! You missed a field.");
      return;
    }

    const users = JSON.parse(localStorage.getItem("corgi-users") || "[]");

    if (isLogin) {
      const user = users.find((u: any) => u.username === username && u.password === password);
      if (user) {
        onAuth({ username: user.username }, false);
      } else {
        setError("Sniff... We don't recognize those paws.");
      }
    } else {
      if (users.some((u: any) => u.username === username)) {
        setError("That pup-name is already taken!");
        return;
      }
      const newUser = { username, password };
      users.push(newUser);
      localStorage.setItem("corgi-users", JSON.stringify(users));
      onAuth({ username }, false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: theme.bg }}>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white rounded-[3rem] p-8 shadow-2xl border-4 text-center space-y-8"
        style={{ borderColor: theme.border }}
      >
        <div className="flex flex-col items-center gap-4">
          <div className="p-4 rounded-3xl" style={{ backgroundColor: theme.primary }}>
            <Dog size={48} className="text-white" />
          </div>
          <h2 className="text-3xl font-black">Corgi<span style={{ color: theme.primary }}>Stash</span></h2>
          <p className="opacity-60 text-sm">{isLogin ? "Welcome back to the pack!" : "Join the fluffiest web stash."}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
            type="text" 
            placeholder="Pup Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full p-4 rounded-2xl border-2 outline-none focus:ring-0 transition-all font-medium"
            style={{ borderColor: theme.border, backgroundColor: theme.input }}
          />
          <input 
            type="password" 
            placeholder="Secret Paw-sword"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-4 rounded-2xl border-2 outline-none focus:ring-0 transition-all font-medium"
            style={{ borderColor: theme.border, backgroundColor: theme.input }}
          />
          
          {error && <p className="text-xs font-bold text-red-500 animate-pulse">{error}</p>}

          <button 
            type="submit" 
            className="w-full p-4 rounded-2xl text-white font-bold text-lg shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-all"
            style={{ backgroundColor: theme.primary }}
          >
            {isLogin ? "Bite In!" : "Join the Pack"}
          </button>
        </form>

        <div className="space-y-4 pt-4">
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-sm font-bold opacity-40 hover:opacity-100 transition-opacity"
          >
            {isLogin ? "Don't have an account? Sign up" : "Already a member? Log in"}
          </button>
          
          <div className="flex items-center gap-4 py-2">
            <div className="flex-1 h-px bg-gray-100" />
            <span className="text-xs font-black opacity-20 uppercase tracking-widest">Or</span>
            <div className="flex-1 h-px bg-gray-100" />
          </div>

          <button 
            onClick={() => onAuth(null, true)}
            className="w-full p-4 rounded-2xl border-2 border-dashed font-bold opacity-60 hover:opacity-100 hover:bg-gray-50 transition-all flex flex-col items-center"
            style={{ borderColor: theme.border }}
          >
            <span>Solo Pup (Guest)</span>
            <span className="text-[10px] font-normal opacity-50 italic">Be aware: session data will be lost</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
