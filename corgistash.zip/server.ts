import express from "express";
import { createServer } from "node:http";
import { createBareServer } from "@tomphttp/bare-server-node";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createServer as createViteServer } from "vite";
import compression from "compression";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const bare = createBareServer("/bare/");
const app = express();
const server = createServer();

app.use(compression());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the game stash
app.use("/games", express.static(path.join(__dirname, "the-game-stash")));

// Serve UV scripts locally for maximum speed
app.use("/uv", express.static(path.join(__dirname, "public", "uv")));
app.use("/uv", express.static(path.join(__dirname, "node_modules", "@titaniumnetwork-dev", "ultraviolet", "dist")));

// API for health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", engine: "CorgiStash-Proxy" });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== "true",
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(__dirname));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "index.html"));
    });
  }

  server.on("request", (req, res) => {
    if (bare.shouldRoute(req)) {
      console.log(`[Bare] Routing: ${req.url}`);
      bare.routeRequest(req, res);
    } else {
      app(req, res);
    }
  });

  server.on("upgrade", (req, socket, head) => {
    if (bare.shouldRoute(req)) {
      console.log(`[Bare-WS] Routing: ${req.url}`);
      bare.routeUpgrade(req, socket, head);
    } else {
      console.log(`[Vite-WS/Other] Upgrade requested for: ${req.url} - Not handled by Bare`);
      socket.end();
    }
  });

  const PORT = Number(process.env.PORT) || 3000;
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`CorgiStash is running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
